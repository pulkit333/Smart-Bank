/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.couchbase.client.java.Bucket;
import com.couchbase.client.java.Cluster;
import com.couchbase.client.java.CouchbaseCluster;
import com.couchbase.client.java.document.json.JsonArray;
import com.couchbase.client.java.document.json.JsonObject;
import com.couchbase.client.java.query.*;

import static com.couchbase.client.java.query.Select.select;
import static com.couchbase.client.java.query.dsl.Expression.i;

public class Application {
    public static void main(String args[]) {
        // Connect to localhost
        Cluster cluster = CouchbaseCluster.create();

        // Open the default bucket and the "beer-sample" one
        Bucket defaultBucket = cluster.openBucket();
        Bucket SampleBucket = cluster.openBucket("smartbank","nickcater");

        Statement statement = select("smartbank[0].FirstName").from(i("smartbank")).limit(5);
        SimpleQuery q = SimpleQuery.simple(statement);

        for (QueryRow row : SampleBucket.query(q)) {
            System.out.println(row);
        // Disconnect and clear all allocated resources
            //cluster.disconnect();
        }
 Bucket smartBank = cluster.openBucket("smartbank","nickcater");
        Bucket savingsT = cluster.openBucket("SavingsT","nickcater");
        Bucket accounts = cluster.openBucket("Accounts","nickcater");
        Bucket accountsT = cluster.openBucket("AccountsT","nickcater");
        
        Statement statement1 = select("smartbank[0].CustomerId").from(i("smartbank"));
        SimpleQuery qq = SimpleQuery.simple(statement1);
        QueryResult row = smartBank.query(qq);
        
        Statement acc = select("*").from(i("Accounts"));
        SimpleQuery q1 = SimpleQuery.simple(acc);
        String s="";
        String AccountN="";
        int i=0;
        System.out.println(i);
        for(QueryRow row1 : accounts.query(q1))
        {
            
        System.out.println(i);
            s = row1.value()
                    .getObject("Accounts")
                    .getArray("Type")
                    .get(i)
                    .toString();
            if(s.equalsIgnoreCase("Savings"))
            {
                
        System.out.println(i);
                AccountN = row1.value()
                        .getObject("Accounts")
                        .getArray("AccountNumber")
                        .get(i)
                        .toString();
            }
            ++i;
                
            Statement statement11 = select("TransactionId")
                    .from(i("AccountsT"));
            SimpleQuery q2 = SimpleQuery.simple(statement11);
            
        System.out.println(q2);
            for(QueryRow row4 : accountsT.query(q2))
            {
                
        System.out.println(i);
            JsonArray arr= row4.value().getArray("TransactionId");
            int j=0;
                
            Statement statement2;
             statement2 = select("*")
                     .from(i("SavingsT"));
             ++j;
             SimpleQuery q3 = SimpleQuery.simple(statement2);
             for(QueryRow row3 : savingsT.query(q3))
             {
                 JsonObject o = row3.value();
               //  System.out.print(o.getObject("SavingsT").get("AccountNumber"));
                 if(o.getObject("SavingsT").get("AccountNumber").equals("1000000001"))
                 System.out.println(o.getObject("SavingsT").get("Type"));
             }
            }
        }
    }
}